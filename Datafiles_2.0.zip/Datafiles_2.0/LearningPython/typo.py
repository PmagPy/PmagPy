#! /usr/bin/env python
abeg = 2.1
aend = 3.9
adif = aend - abge
print 'adif = ', adif
