#!/usr/bin/env python
mylist=[42,`spam',`ocelot']
for i in range(len(mylist)): # note absence of Indices list, min and interval
   print mylist[i]
print 'All done' 
